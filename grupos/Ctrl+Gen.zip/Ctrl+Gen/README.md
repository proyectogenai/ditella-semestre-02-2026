# Grupo 7

Somos el **Grupo 7**, tres estudiantes de Diseño de la Licenciatura en
Diseño de la Universidad Torcuato Di Tella, en la materia **IA Generativa y
Diseño**.

## Integrantes

- **Clementina Ogallar** — Sociable y alegre, muy curiosa, le encanta
  aprender y bailar. Amante de las bufandas, el helado y la playa.
- **Delfina Garcia Lema** —Comunicación, organización, responsabilidad 
  y perseverancia son cualidades que me caracterizan.
- **Martina Isla** — Intensa, extrovertida, curiosa e inquieta.
