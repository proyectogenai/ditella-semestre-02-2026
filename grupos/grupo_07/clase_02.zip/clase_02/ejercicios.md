# Clase 2 · Ejercicios

**Copiá este archivo a tu carpeta de grupo antes de empezar:**

```
cp clases/clase_02/ejercicios.md grupos/grupo_XX/clase_02/
```

Después completalo ahí. Es tu hoja de trabajo de la clase y parte del
entregable.

> 🎓 **Recordá cómo pedirle al agente.** Lo mecánico (comandos, errores,
> crear carpetas) que lo resuelva él. Lo que es criterio de diseño lo escribís
> vos, y él te guía con preguntas. Si querés trabajar así, pegale esto al
> inicio del chat:
> *"Trabajemos en modo tutor: guiame de a un paso por vez, hacéme las preguntas
> que necesites y esperá mi respuesta antes de seguir. No escribas por mí las
> partes que son decisión de diseño."*

---

# PARTE A · Individual

## A.1 — Mi marca

**Marca elegida:** _propia_ — emprendimiento de empanadas salteñas artesanales con delivery

**En dos líneas, qué es:**
Empanadas salteñas hechas en fábrica artesanal con alta calidad productiva: las
pedís y te las llevan a la puerta de tu casa, de manera eficaz y coordinada.
Especiales, ricas y originales, pensadas para acompañar un encuentro entre
amigos y familia.

**Tres adjetivos de su atmósfera:** cálida, hogareña, artesanal.

**Tres cosas que esta marca NUNCA es:** fuerte (de picante que tapa todo),
pesada (que cae mal), ni de la que te llenás con poca cantidad (es ideal para
sumar a una picada).

---

## A.2 — Mi system prompt

Completá las cinco partes. Si una te sale de una línea, probablemente le falte
especificidad.

```
# ROL
Sos el/la fotógrafo/a gastronómico/a y director/a de arte de un
emprendimiento artesanal de empanadas salteñas con delivery. Tu única tarea
es convertir pedidos cortos del equipo en prompts de imagen completos y
consistentes.

# EL UNIVERSO DE [TU MARCA]
Un emprendimiento artesanal que hace empanadas salteñas de alta calidad y te
las lleva a la puerta de tu casa. Su mundo transcurre alrededor de una mesa
con amigos y familia: empanadas en el centro, manos que se sirven, clima de
encuentro compartido.
Su mundo visual: mesa de madera clara, mantel de lino, canasto de mimbre con
empanadas, luz natural de ventana cayendo suave.
Atmósfera: cálida, hogareña, artesanal · Nunca: picante que tapa todo, pesada
que cae mal, ni de la que te llenás con poca cantidad.

# BLOQUE DE ESTILO (va SIEMPRE, sin modificar)
food photography with a lifestyle feel, soft natural window light, palette of
salteño green, terracotta, toasted golden brown, cream and light wood,
minimalist composition with only one or two elements in frame, generous
negative space, appetizing close-up with visible flaky masa texture, shallow
depth of field, high quality, natural unposed composition, no text, no logos

# CÓMO RESPONDER
1. Elegí UN encuadre de esta lista, rotando entre pedidos para que las
   piezas no se parezcan entre sí:
   - mesa limpia de madera clara con un canasto de mimbre con empanadas al
     centro, sin otros elementos alrededor
   - primer plano del repulgue con la masa dorada y hojaldrada
   - caja de empanadas llegando a la puerta de una casa
2. Escribí el prompt: [escena específica] + [bloque de estilo] + [formato]
3. Devolvé SOLO el prompt final en inglés, en un bloque de código.
   Sin explicaciones, sin alternativas, sin preguntas.

# RESTRICCIONES
- Nunca generes texto ni tipografía dentro de la imagen.
- Nunca llenes la escena de elementos: máximo dos objetos en cuadro.
- Nunca muestres empanadas quemadas, secas ni de aspecto industrial.
- Nunca uses luz fría como luz principal.
- Si el pedido es ambiguo, elegí vos y avanzá. No preguntes.
```

**Chequeo rápido antes de probarlo:**

- [x] Mi bloque de estilo nombra **colores concretos**, no "lindos" ni "modernos"
- [x] Dice qué **luz** tiene la escena
- [x] Tiene una sección de **formato**: qué me devuelve exactamente
- [x] Tiene una **regla de variación** para que las piezas no salgan idénticas

---

## A.3 — Los tres pedidos

Abrí un chat nuevo, pegá tu system prompt y mandale tres pedidos cortos y de
naturaleza distinta.

| # | Mi pedido | ¿Qué tal salió? |
| --- | --- | --- |
| 1 | Mesa de amigos compartiendo empanadas al atardecer | Primera versión: demasiados elementos, mucho ruido visual, poco realista. Tras la iteración quedó limpia y acorde. |
| 2 | Primer plano del repulgue con masa dorada | Buena textura, coherente con la marca. |
| 3 | Caja de empanadas llegando a la puerta | Buena, clara, con el tono correcto de delivery. |

Guardá las imágenes en `imagenes/` con nombres claros (`individual_01.png`).

---

## A.4 — La iteración (lo más importante)

**Mirá las tres imágenes juntas y respondé honestamente:**

| Pregunta | Sí / No | Si la respuesta es mala, qué falta |
| --- | --- | --- |
| ¿Parecen de la misma marca? | Sí | |
| ¿Parecen todas la misma imagen? | No | |
| ¿Tuviste que arreglar algo a mano? | No | Se resolvió cambiando el sistema |

**El cambio que hice al system prompt:**
Agregué al bloque de estilo la regla: "minimalist composition with only one
or two elements in frame, generous negative space". Agregué la restricción:
"nunca llenes la escena de elementos: máximo dos objetos en cuadro". Simplifiqué
la escena de mesa a "mesa limpia de madera clara con un canasto de empanadas,
sin otros elementos alrededor".

**Volví a probar el pedido que peor salió y ahora:**
Quedó limpia, profesional y realista. Menos elementos en la escena, colores
armónicos, y la empanada se siente como protagonista sin ruido visual
alrededor.

---

# PARTE B · Grupal

## B.1 — La marca del grupo

**Marca elegida y por qué:**

## B.2 — Qué tomamos de cada asistente

| De quién | Qué le tomamos | Por qué |
| --- | --- | --- |
| | | |
| | | |
| | | |

**Qué decidimos dejar afuera y por qué:**

## B.3 — La prueba cruzada

Cada integrante, desde **su propia compu** y en un **chat limpio**:

| Integrante | Su pedido (tipo) | Imagen |
| --- | --- | --- |
| | ambiente | |
| | detalle | |
| | anuncio | |

**Las tres imágenes juntas, ¿parecen de la misma marca?**

**Si no: ¿qué regla le falta al asistente del grupo?**

> Esta última pregunta es la que se va a evaluar en el parcial, pero con la
> skill de **otro grupo**. Un sistema que solo funciona en las manos de quien
> lo escribió no es un sistema.

---

# Entregable

En `grupos/grupo_XX/clase_02/`:

```
clase_02/
├── ejercicios.md                  ← este archivo, completado
├── asistente_nombre_apellido.md   ← uno por integrante (3)
├── asistente_grupal.md
└── imagenes/
```

Y el push de siempre:

```
git pull
git add grupos/grupo_XX/
git commit -m "grupo XX: clase 02"
git push
```
